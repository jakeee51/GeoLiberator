# -*- coding: utf-8 -*-
'''
Author: David J. Morfe
Application Name: GeoLiberator Demo
Functionality Purpose: Demonstrate the address parsing module 'GeoLiberator'
7/3/19
'''

name = "GeoLiberator"
##from geoliberator import GeoLiberator, geoLiberate, autoGeoLiberate
